This repository is for our robotics project. It includes the code, 3D design and task sheet
